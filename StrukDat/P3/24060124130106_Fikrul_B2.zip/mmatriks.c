/* Program   : mmatriks.c */
/* Deskripsi : driver ADT matriks integer */
/* NIM/Nama  : */
/* Tanggal   : */
/***********************************/

#include <stdio.h>
#include "matriks.h"
int main() {
	/*kamus*/
	Matriks M1, M2, M3;
	/*algoritma*/
    printf("MATRIKS\n\n");
    printf("=======================================================\n");
    printf("Input Matriks 1 dengan nilai:\n1 2 3 4\n5 6 7 8\n9 10 11 12\n13 14 15 16\n\n");
    initMatriks(&M1);
    addX(&M1, 1, 1, 1); addX(&M1, 2, 1, 2); addX(&M1, 3, 1, 3); addX(&M1, 4, 1, 4); 
    addX(&M1, 5, 2, 1); addX(&M1, 6, 2, 2); addX(&M1, 7, 2, 3); addX(&M1, 8, 2, 4); 
    addX(&M1, 9, 3, 1); addX(&M1, 10, 3, 2); addX(&M1, 11, 3, 3); addX(&M1, 12, 3, 4); 
    addX(&M1, 13, 4, 1); addX(&M1, 14, 4, 2); addX(&M1, 15, 4, 3); addX(&M1, 16, 4, 4);
    M1.nbaris = 4; M1.nkolom = 4;
    printf("b");
    printf("\nHasil dari matriks 1:\n\n");
    printMatriks(M1);
    printf("\n\n");
    printf("Hasil view matriks 1:\n\n");
    viewMatriks(M1);
    printf("\n\n");
    printf("Menghapus elemen 10 pada matriks 1\n\n");
    delX(&M1, 10);
    printf("Hasil view matriks 1:\n\n");
    viewMatriks(M1);
    printf("\n\n");
	return 0;
}