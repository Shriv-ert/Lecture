#ifndef boolean_H
#define boolean_H
/*Deskripsi : boolean*/
/* NIM/Nama  : 24060124130106 /Shofwan Fikrul Huda */
/* Tanggal   : */
#define true 1
#define false 0
#define boolean unsigned char
#endif