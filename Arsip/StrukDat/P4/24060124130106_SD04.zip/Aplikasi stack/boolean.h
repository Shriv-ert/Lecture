/*  Program     : boolean.h
    Deskripsi   : Header file modul boolean.
    NIM/Nama    : 24060124140179 / Adam M. R
    Tanggal     : 21/09/2025*/
#ifndef boolean_H
#define boolean_H

#define true 1
#define false 0
#define boolean unsigned char

#endif